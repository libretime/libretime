/* ***** BEGIN LICENSE BLOCK *****
 * Source last modified: $Id: hxh263d.cpp,v 1.3 2004/07/09 18:32:02 hubbe Exp $
 * 
 * Portions Copyright (c) 1995-2004 RealNetworks, Inc. All Rights Reserved.
 * 
 * The contents of this file, and the files included with this file,
 * are subject to the current version of the RealNetworks Public
 * Source License (the "RPSL") available at
 * http://www.helixcommunity.org/content/rpsl unless you have licensed
 * the file under the current version of the RealNetworks Community
 * Source License (the "RCSL") available at
 * http://www.helixcommunity.org/content/rcsl, in which case the RCSL
 * will apply. You may also obtain the license terms directly from
 * RealNetworks.  You may not use this file except in compliance with
 * the RPSL or, if you have a valid RCSL with RealNetworks applicable
 * to this file, the RCSL.  Please see the applicable RPSL or RCSL for
 * the rights, obligations and limitations governing use of the
 * contents of the file.
 * 
 * Alternatively, the contents of this file may be used under the
 * terms of the GNU General Public License Version 2 or later (the
 * "GPL") in which case the provisions of the GPL are applicable
 * instead of those above. If you wish to allow use of your version of
 * this file only under the terms of the GPL, and not to allow others
 * to use your version of this file under the terms of either the RPSL
 * or RCSL, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by
 * the GPL. If you do not delete the provisions above, a recipient may
 * use your version of this file under the terms of any one of the
 * RPSL, the RCSL or the GPL.
 * 
 * This file is part of the Helix DNA Technology. RealNetworks is the
 * developer of the Original Code and owns the copyrights in the
 * portions it created.
 * 
 * This file, and the files included with this file, is distributed
 * and made available on an 'AS IS' basis, WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESS OR IMPLIED, AND REALNETWORKS HEREBY DISCLAIMS
 * ALL SUCH WARRANTIES, INCLUDING WITHOUT LIMITATION, ANY WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, QUIET
 * ENJOYMENT OR NON-INFRINGEMENT.
 * 
 * Technology Compatibility Kit Test Suite(s) Location:
 *    http://www.helixcommunity.org/content/tck
 * 
 * Contributor(s):
 * 
 * ***** END LICENSE BLOCK ***** */

#define INITGUID
#include "hxtypes.h"
#include "ihxpckts.h"
#include "hxvamain.h"
#include "h263vdec.h"
#include "hxcinst.h"
#include "hvviddec.h"

//#define DEBUG_WRITEIO
#ifdef DEBUG_WRITEIO // writes the input packets and output yuv
#include "iowriter.h"
YUVFileWriter  *writer = 0;
#endif

HX_RESULT HXEXPORT
HXVtoYUV420Init(HXV10_INIT *pHxvInit, void **decoderState)
{
    HX_RESULT                   result;
    HX_RESULT                  ps = HXR_OK;
	VvVideoDecoderFilter *		decFlt=0;
	HXVA_Image_Format            in_format;
	HXVA_Image_Format            out_format;


    if (!pHxvInit || !decoderState)
        return HXR_POINTER;

	in_format.fid = HXVA_FID_H263PLUS;
    in_format.dimensions.width = pHxvInit->pels;
    in_format.dimensions.height = pHxvInit->lines;
    in_format.Complete();

    out_format.fid = HXVA_FID_YUV12;
    out_format.dimensions = in_format.dimensions;
    out_format.Complete();
    
    // CreateInstance		
	decFlt = VvVideoDecoderFilter::CreateInstance(ps);
	if(!decFlt || ps!=HXR_OK)
		return HXR_OUTOFMEMORY;
	
	ps = HXR_OK;	
	ps = decFlt->StartStreaming(in_format, out_format);
    if(ps != HXR_OK) 
	{
		decFlt->StopStreaming();
		delete decFlt;
		return HXR_INVALID_PARAMETER;
	}
	*decoderState = decFlt;

#ifdef DEBUG_WRITEIO
	BOOL failed;
	if(!writer)
	{
		writer = new YUVFileWriter("c:\\out.yuv", out_format, failed);
		if(!failed)
			writer->Open();
	}
#endif
    return HXR_OK;
}

HX_RESULT HXEXPORT
HXVtoYUV420Free(void *global)
{
	((VvVideoDecoderFilter *)(global))->StopStreaming();
	delete (VvVideoDecoderFilter *)(global);

#ifdef DEBUG_WRITEIO	
	if(writer)
	{
		writer->Close();
		delete writer;
	}
#endif

	return HXR_OK;
}



HX_RESULT HXEXPORT
HXVtoYUV420Transform
    (
    UCHAR     *pH263Packets,
    UCHAR     *pDecodedFrameBuffer,
    void      *pInputParams,
    void      *pOutputParams,
    void      *global
    )
{
    HX_RESULT       result;
    HX_RESULT      ps;
    HXVA_Image       src;
    HXVA_Image       dst;
    INT32             temporal_offset = 0;
    ULONG32 flags = 0;
    ULONG32 notes = 0;
	VvVideoDecoderFilter *decFlt;
	
	decFlt = (VvVideoDecoderFilter *)(global);	

    H263DecoderInParams  * pH263In  = (H263DecoderInParams *)pInputParams;
    H263DecoderOutParams * pH263Out = (H263DecoderOutParams *)pOutputParams;

    if (decFlt==0 || !pH263In || !pH263Out)
        return HXR_POINTER;

    pH263Out->numFrames = 0;  // Until we learn otherwise
    pH263Out->notes = 0;
    pH263Out->timestamp = 0;
    
    src.format = decFlt->m_input_format;
    src.size = pH263In->dataLength;
    src.sequence_number = pH263In->timestamp;  // presentation time
    src.SetBasePointer(pH263Packets);

    dst.format = decFlt->m_output_format;
    dst.size = 0;

    dst.sequence_number = src.sequence_number;
    dst.SetBasePointer(pDecodedFrameBuffer);

	ps = decFlt->Receive( src, dst);	
	if(ps!=HXR_OK)
	{
		pH263Out->numFrames = 1;
		pH263Out->notes |= RV_DECODE_DONT_DRAW;
		pH263Out->width = decFlt->m_output_format.dimensions.width;
		pH263Out->height = decFlt->m_output_format.dimensions.height;
		if(dst.size == 0) 
		{
			dst.size = (pH263Out->width * pH263Out->height);
			dst.size += (dst.size >> 1);
		}
		// Assign the presentation time for the display frame
		pH263Out->timestamp = dst.sequence_number++;
		return HXR_OK;
	}

	// Assign the number of frames out
    pH263Out->numFrames = 1;
    pH263Out->notes = 0;
	pH263Out->width = decFlt->m_output_format.dimensions.width;
	pH263Out->height = decFlt->m_output_format.dimensions.height;
	if(dst.size == 0) 
    {
        dst.size = (pH263Out->width * pH263Out->height);
        dst.size += (dst.size >> 1);
    }
	// Assign the presentation time for the display frame
    pH263Out->timestamp = dst.sequence_number++;

#ifdef DEBUG_WRITEIO
	if (writer && !(notes & RV_DECODE_DONT_DRAW))
    {
		writer->Write(dst);
    }
#endif

    return HXR_OK;
}

