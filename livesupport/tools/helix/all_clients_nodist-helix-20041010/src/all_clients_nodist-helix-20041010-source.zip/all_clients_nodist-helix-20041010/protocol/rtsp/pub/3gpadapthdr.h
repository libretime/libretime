/* ***** BEGIN LICENSE BLOCK *****
 * Version: RCSL 1.0/RPSL 1.0
 *
 * Portions Copyright (c) 1995-2002 RealNetworks, Inc. All Rights Reserved.
 *
 * The contents of this file, and the files included with this file, are
 * subject to the current version of the RealNetworks Public Source License
 * Version 1.0 (the "RPSL") available at
 * http://www.helixcommunity.org/content/rpsl unless you have licensed
 * the file under the RealNetworks Community Source License Version 1.0
 * (the "RCSL") available at http://www.helixcommunity.org/content/rcsl,
 * in which case the RCSL will apply. You may also obtain the license terms
 * directly from RealNetworks.  You may not use this file except in
 * compliance with the RPSL or, if you have a valid RCSL with RealNetworks
 * applicable to this file, the RCSL.  Please see the applicable RPSL or
 * RCSL for the rights, obligations and limitations governing use of the
 * contents of the file.
 *
 * This file is part of the Helix DNA Technology. RealNetworks is the
 * developer of the Original Code and owns the copyrights in the portions
 * it created.
 *
 * This file, and the files included with this file, is distributed and made
 * available on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND REALNETWORKS HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 *
 * Technology Compatibility Kit Test Suite(s) Location:
 *    http://www.helixcommunity.org/content/tck
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** */
#ifndef _3GP_ADAPT_HDR_H
#define _3GP_ADAPT_HDR_H

#include "hxtypes.h"
#include "hxcom.h"
#include "ihxpckts.h"
#include "ihxpckts.h"
#include "hxccf.h"

class C3gpAdaptationHeader
{
public:
    C3gpAdaptationHeader();


    ~C3gpAdaptationHeader();

    bool operator==(const C3gpAdaptationHeader& rhs);

    HX_RESULT Init(IUnknown* pContext);

    HX_RESULT Parse(const char* pBuf, UINT32 ulSize);
    HX_RESULT GetValues(REF(IHXValues*) pValues);

    HX_RESULT SetValues(IHXValues* pValues);
    HX_RESULT GetString(REF(IHXBuffer*) pBuf);

    HX_RESULT Copy(const C3gpAdaptationHeader& rhs);

private:
    // Hide copy constructor and assignment operator. If you want
    // to copy this object use the Copy() function
    C3gpAdaptationHeader(const C3gpAdaptationHeader& rhs);
    C3gpAdaptationHeader& operator=(const C3gpAdaptationHeader& rhs);

    HX_RESULT GetURL(REF(const char*) pCur, const char* pEnd);
    HX_RESULT GetAdaptParam(REF(const char*) pCur, const char* pEnd);
    HX_RESULT GetIntParam(const char* pName, REF(const char*) pCur, 
                          const char* pEnd);
    HX_RESULT GetStringParam(const char* pName, REF(const char*) pCur, 
                             const char* pEnd);

    BOOL IsIntParam(const char* pName);
    BOOL IsStringParam(const char* pName);
    BOOL InKeyList(const char* pName, const char** pList, UINT32 uSize);
    
    bool CompareIHXValues(IHXValues* pA, IHXValues* pB);
    HX_RESULT CopyIHXValues(IHXValues* pA);
    
    BOOL AreValuesValid(IHXValues* pA);
    BOOL IsValidURL(const char* pURL);

    HX_RESULT AddURL(IHXBuffer* pBuf, IHXBuffer* pURL);
    HX_RESULT AddStringParam(IHXBuffer* pBuf,
                             const char* pKey, IHXBuffer* pValue);
    HX_RESULT AddULONG32Param(IHXBuffer* pBuf,
                              const char* pKey, ULONG32 ulValue);

    IHXCommonClassFactory* m_pCCF;
    IHXValues* m_pValues;

    static const char* zm_pIntParams[];
    static const char* zm_pStringParams[];
};
#endif /* _3GP_ADAPT_HDR_H */
