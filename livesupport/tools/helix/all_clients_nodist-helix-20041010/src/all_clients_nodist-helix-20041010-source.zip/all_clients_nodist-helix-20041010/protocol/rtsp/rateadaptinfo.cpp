/* ***** BEGIN LICENSE BLOCK *****  
 * Source last modified: $Id: rateadaptinfo.cpp,v 1.2 2004/06/29 16:58:54 acolwell Exp $ 
 *   
 * Portions Copyright (c) 1995-2004 RealNetworks, Inc. All Rights Reserved.  
 *       
 * The contents of this file, and the files included with this file, 
 * are subject to the current version of the RealNetworks Public 
 * Source License (the "RPSL") available at 
 * http://www.helixcommunity.org/content/rpsl unless you have licensed 
 * the file under the current version of the RealNetworks Community 
 * Source License (the "RCSL") available at 
 * http://www.helixcommunity.org/content/rcsl, in which case the RCSL 
 * will apply. You may also obtain the license terms directly from 
 * RealNetworks.  You may not use this file except in compliance with 
 * the RPSL or, if you have a valid RCSL with RealNetworks applicable 
 * to this file, the RCSL.  Please see the applicable RPSL or RCSL for 
 * the rights, obligations and limitations governing use of the 
 * contents of the file. 
 *   
 * This file is part of the Helix DNA Technology. RealNetworks is the 
 * developer of the Original Code and owns the copyrights in the 
 * portions it created. 
 *   
 * This file, and the files included with this file, is distributed 
 * and made available on an 'AS IS' basis, WITHOUT WARRANTY OF ANY 
 * KIND, EITHER EXPRESS OR IMPLIED, AND REALNETWORKS HEREBY DISCLAIMS 
 * ALL SUCH WARRANTIES, INCLUDING WITHOUT LIMITATION, ANY WARRANTIES 
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, QUIET 
 * ENJOYMENT OR NON-INFRINGEMENT. 
 *  
 * Technology Compatibility Kit Test Suite(s) Location:  
 *    http://www.helixcommunity.org/content/tck  
 *  
 * Contributor(s):  
 *   
 * ***** END LICENSE BLOCK ***** */  
#include "rateadaptinfo.h"
#include "hxasm.h"
#include "hxcore.h"
#include "pckunpck.h"
#include "3gpadapthdr.h"

// There is nothing magical about these constants. The just
// seemed like reasonable maximums
const ULONG32 Max3gpAdaptTargetTime = 60000; // in milliseconds
const ULONG32 Max3gpAdaptBufferSize = 3000000; // in bytes

class HXRAIStreamInfo
{
public:
    HXRAIStreamInfo();
    ~HXRAIStreamInfo();

    HX_RESULT Init(UINT16 uStreamNumber,
                   UINT32 ulReportFreq,
                   IHXValues* pHdr);

    UINT16 StreamNumber() const {return m_uStreamNumber;}
    UINT32 Get3gpBufferSize() const;
    UINT32 Get3gpTargetTime() const;
    UINT32 Get3gpReportFreq() const;

private:
    UINT16 m_uStreamNumber;
    UINT32 m_ulBufferSize;
    UINT32 m_ulTargetTime;
    UINT32 m_ulReportFreq;
};

HXRAIStreamInfo::HXRAIStreamInfo() :
    m_uStreamNumber(0),
    m_ulBufferSize(0),
    m_ulTargetTime(0),
    m_ulReportFreq(0)
{}

HXRAIStreamInfo::~HXRAIStreamInfo()
{}

HX_RESULT 
HXRAIStreamInfo::Init(UINT16 uStreamNumber,
                      UINT32 ulReportFreq,
                      IHXValues* pHdr)
{
    HX_RESULT res = HXR_FAILED;
    ULONG32 ulAvgBitRate = 0;
    ULONG32 ulPreroll = 0;

    if (pHdr &&
        (HXR_OK == pHdr->GetPropertyULONG32("AvgBitRate",
                                            ulAvgBitRate)) &&
        (HXR_OK == pHdr->GetPropertyULONG32("Preroll",
                                            ulPreroll)) &&
        (ulAvgBitRate > 0) &&
        (ulPreroll > 0))
    {
        // Just use 2x preroll for our target-time. There is
        // nothing magic about this number other than it is >
        // the preroll
        m_ulTargetTime = MIN(2 * ulPreroll,
                             Max3gpAdaptTargetTime);

        // Compute the buffer size to be enough bytes to contain
        // m_ulTargetTime worth of data at ulAvgBitRate
        ULONG32 ulBytesPerSec = ulAvgBitRate / 8;
        ULONG32 ulQ = ulBytesPerSec / 1000;
        ULONG32 ulR = ulBytesPerSec - ulQ * 1000;
        ULONG32 ulMult = m_ulTargetTime;
        m_ulBufferSize = ulQ * ulMult + (ulR * ulMult) / 1000;

        // Apply an upper limit to this value
        m_ulBufferSize = MIN(m_ulBufferSize, Max3gpAdaptBufferSize);

        m_ulReportFreq = ulReportFreq;
        m_uStreamNumber = uStreamNumber;

        res = HXR_OK;
    }

    return res;
}

UINT32 HXRAIStreamInfo::Get3gpBufferSize() const
{
    return m_ulBufferSize;
}

UINT32 HXRAIStreamInfo::Get3gpTargetTime() const
{
    return m_ulTargetTime;
}

UINT32 HXRAIStreamInfo::Get3gpReportFreq() const
{
    return m_ulReportFreq;
}

CHXRateAdaptationInfo::CHXRateAdaptationInfo() :
    m_pRateAdaptCtl(NULL),
    m_pCCF(NULL),
    m_pOBSN(NULL)
{}

CHXRateAdaptationInfo::~CHXRateAdaptationInfo()
{
    Close();
}

HX_RESULT CHXRateAdaptationInfo::Init(IUnknown* pContext)
{
    HX_RESULT res = HXR_POINTER;

    if (pContext)
    {
        res = pContext->QueryInterface(IID_IHXClientRateAdaptControl,
                                       (void**)&m_pRateAdaptCtl);

        if (HXR_OK == res)
        {
            res = pContext->QueryInterface(IID_IHXCommonClassFactory,
                                           (void**)&m_pCCF);
        }

        if (HXR_OK == res)
        {
            res = pContext->QueryInterface(IID_IHX3gppOBSN,
                                           (void**)&m_pOBSN);
        }
    }

    return res;
}

HX_RESULT CHXRateAdaptationInfo::Close()
{
    while(!m_streamInfo.IsEmpty())
    {
        HXRAIStreamInfo* pInfo = 
            (HXRAIStreamInfo*)m_streamInfo.RemoveHead();
        HX_DELETE(pInfo);
    }
    
    HX_RELEASE(m_pRateAdaptCtl);
    HX_RELEASE(m_pCCF);
    HX_RELEASE(m_pOBSN);

    return HXR_OK;
}

// Called when we get a stream header
HX_RESULT 
CHXRateAdaptationInfo::OnStreamHeader(UINT16 uStreamNumber,
                                      IHXValues* pHdr)
{
    HX_RESULT res = HXR_OK;
    ULONG32 ulReportFreq;

    if (!pHdr)
    {
        res = HXR_POINTER;
    }
    else if (m_pRateAdaptCtl && m_pOBSN &&
             (HXR_OK == pHdr->GetPropertyULONG32("3GPP-Adaptation-Support",
                                                 ulReportFreq)))
    {
        HXRAIStreamInfo* pInfo = new HXRAIStreamInfo;

        if (pInfo)
        {
            res = pInfo->Init(uStreamNumber,
                              ulReportFreq,
                              pHdr);
            
            if ((HXR_OK == res) &&
                (!m_streamInfo.AddTail(pInfo)))
            {
                res = HXR_OUTOFMEMORY;
            }

            if (HXR_OK != res)
            {
                HX_DELETE(pInfo);
            }
        }
        else
        {
            res = HXR_OUTOFMEMORY;
        }
    }
    
    return res;
}

HX_RESULT 
CHXRateAdaptationInfo::CreateRateAdaptHeaders(UINT16 uStreamNumber,
                                              const char* pStreamURL,
                                              REF(IHXValues*) pHdrs)
{
    HX_RESULT res = HXR_FAILED;
    HXRAIStreamInfo* pInfo = GetStreamInfo(uStreamNumber);

    pHdrs = NULL;

    if (pInfo)
    {
        IHXBuffer* pAdaptStr = Create3gpAdaptHdrs(pStreamURL,
                                                  pInfo);
        
        if (pAdaptStr)
        {
            res = CreateValuesCCF(pHdrs, m_pCCF);
            
            if (HXR_OK == res)
            {
                res = pHdrs->SetPropertyCString("3GPP-Adaptation",
                                                pAdaptStr);
            }
            
            if(HXR_OK != res)
            {
                HX_RELEASE(pHdrs);
            }
        }
        HX_RELEASE(pAdaptStr);
    }

    return res;
}

// Called when the server responds to our
// rate adaptation request
HX_RESULT 
CHXRateAdaptationInfo::OnRateAdaptResponse(UINT16 uStreamNumber,
                                           IHXValues* pReqHdrs,
                                           IHXValues* pRespHdrs)
{
    HX_RESULT res = HXR_FAILED;

    HXRAIStreamInfo* pInfo = GetStreamInfo(uStreamNumber);

    if (pInfo)
    {
        IHXBuffer* pReqField = NULL;
        IHXBuffer* pRespField = NULL;

        // The value in the request must match the value in the
        // response
        if ((HXR_OK == pReqHdrs->GetPropertyCString("3GPP-Adaptation",
                                                    pReqField)) &&
            (HXR_OK == pRespHdrs->GetPropertyCString("3GPP-Adaptation",
                                                     pRespField)) &&
            (pReqField->GetSize() == pRespField->GetSize()) &&
            (!memcmp(pReqField->GetBuffer(), pRespField->GetBuffer(),
                     pReqField->GetSize())))
        {
            // Disable client rate adaptation for this stream
            res = m_pRateAdaptCtl->Disable(uStreamNumber);

            if (HXR_OK == res)
            {
                // Set OBSN report frequency
                res = m_pOBSN->SetOBSNFrequency(uStreamNumber,
                                                pInfo->Get3gpReportFreq());
            }
        }
        else
        {
            RemoveStreamInfo(uStreamNumber);
            res = HXR_OK;
        }

        HX_RELEASE(pReqField);
        HX_RELEASE(pRespField);
    }

    return res;
}

HXRAIStreamInfo* 
CHXRateAdaptationInfo::GetStreamInfo(UINT16 uStreamNumber) const
{
    HXRAIStreamInfo* pInfo = NULL;

    LISTPOSITION pos = m_streamInfo.GetHeadPosition();

    while (!pInfo && pos)
    {
        HXRAIStreamInfo* pTmp = 
            (HXRAIStreamInfo*)m_streamInfo.GetAt(pos);
        
        if (pTmp &&
            (pTmp->StreamNumber() == uStreamNumber))
        {
            pInfo = pTmp;
        }

        m_streamInfo.GetNext(pos);
    }
    return pInfo;
}

void 
CHXRateAdaptationInfo::RemoveStreamInfo(UINT16 uStreamNumber)
{
    BOOL bDone = FALSE;
    LISTPOSITION pos = m_streamInfo.GetHeadPosition();

    while (!bDone && pos)
    {
        HXRAIStreamInfo* pTmp = 
            (HXRAIStreamInfo*)m_streamInfo.GetAt(pos);
        
        if (pTmp &&
            (pTmp->StreamNumber() == uStreamNumber))
        {
            m_streamInfo.RemoveAt(pos);
            HX_DELETE(pTmp);
            bDone = TRUE;
        }
        else
        {
            m_streamInfo.GetNext(pos);
        }
    }
}

IHXBuffer* 
CHXRateAdaptationInfo::Create3gpAdaptHdrs(const char* pStreamURL,
                                          HXRAIStreamInfo* pInfo)
{
    IHXBuffer* pRet = NULL;

    if (pStreamURL && pInfo)
    {
        IHXValues* pValues = NULL;
        C3gpAdaptationHeader adaptHdr;
        
        HX_RESULT res = adaptHdr.Init(m_pCCF);
        ULONG32 ulTargetTime = 
            pInfo->Get3gpTargetTime();
        ULONG32 ulBufferSize = 
            pInfo->Get3gpBufferSize();

        if (HXR_OK == res)
        {
            res = CreateValuesCCF(pValues, m_pCCF);
        }

        if (HXR_OK == res)
        {
            res = SetCStringPropertyCCF(pValues,
                                        "url",
                                        pStreamURL,
                                        m_pCCF);
        }
        
        if (HXR_OK == res)
        {
            res = pValues->SetPropertyULONG32("target-time",
                                              ulTargetTime);
        }
        
        if (HXR_OK == res)
        {
            res = pValues->SetPropertyULONG32("size",
                                              ulBufferSize);
        }
        
        if (HXR_OK == res)
        {
            res = adaptHdr.SetValues(pValues);
        }

        if (HXR_OK == res)
        {
            res = adaptHdr.GetString(pRet);
        }
        
        HX_RELEASE(pValues);
    }

    return pRet;
}
